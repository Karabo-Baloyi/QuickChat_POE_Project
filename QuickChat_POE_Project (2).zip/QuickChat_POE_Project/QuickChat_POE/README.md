# QuickChat POE – Programming 1A

A Java 17, Maven-based **console application** implementing Parts 1, 2 and 3 of the PROG5121 POE.

## Requirements
- JDK 17 or later
- Apache Maven 3.8+
- NetBeans, IntelliJ IDEA, or another Java IDE
- Git and a GitHub account for submission

## Run in NetBeans
1. Extract the ZIP file.
2. Open NetBeans and choose **File → Open Project**.
3. Select the extracted `QuickChat_POE` folder (the folder containing `pom.xml`).
4. Allow Maven to download the dependencies.
5. Run `za.co.quickchat.QuickChatApp`.

## Run from a terminal
From the project folder:

```bash
mvn clean test
mvn exec:java -Dexec.mainClass="za.co.quickchat.QuickChatApp"
```

If your Maven installation does not have the exec plugin available, run `QuickChatApp` from the IDE instead.

## What is implemented?
- Registration and login with the required username, password and South African cellphone validation.
- Console menu: Send Messages, Show Recently Sent Messages, Quit, and Stored Messages.
- Message ID generation, message numbering, message hashes and send/store/disregard choices.
- Dynamically populated message collections and corresponding ID/hash arrays.
- JSON persistence in `data/stored_messages.json`.
- Stored-message options: sender/recipient listing, longest stored message, ID search, recipient search, hash deletion and full report.
- JUnit 5 tests and GitHub Actions workflow.

## JSON file
Stored messages are written to `data/stored_messages.json` relative to the working directory. The `data` directory is created automatically.

## Important assignment notes
- The POE describes a console-only application; this project does not use Swing or JOptionPane.
- The POE's examples use South African numbers such as `+27834557896`. The validator therefore accepts `+27` followed by nine digits. This preserves the supplied international-format examples, although the document's wording about a ten-character limit is ambiguous.
- The Part 3 rubric's message-4 search example labels `0838884567` as a message ID, while the earlier requirements say IDs are randomly generated ten-digit values. The implementation follows the randomly generated ID requirement. Search by ID uses the actual generated ID printed when a message is created.
- Update the GitHub repository URL and add your own commits. The assignment requires at least six commits for each submitted part and a voice-over presentation in your own voice.
