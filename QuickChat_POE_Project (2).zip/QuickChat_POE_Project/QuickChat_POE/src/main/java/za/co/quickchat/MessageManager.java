package za.co.quickchat;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


public class MessageManager {
    private Message[] sentMessages = new Message[0];
    private Message[] disregardedMessages = new Message[0];
    private Message[] storedMessages = new Message[0];
    private String[] messageHashes = new String[0];
    private String[] messageIds = new String[0];
    private final ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
    private final Path jsonFile;

    public MessageManager() { this(Path.of("data", "stored_messages.json")); }

    public MessageManager(Path jsonFile) {
        this.jsonFile = jsonFile;
        loadStoredMessages();
    }

    public void add(Message message) {
        switch (message.getStatus()) {
            case SENT -> sentMessages = append(sentMessages, message);
            case DISREGARDED -> disregardedMessages = append(disregardedMessages, message);
            case STORED -> {
                storedMessages = append(storedMessages, message);
                saveStoredMessages();
            }
        }
        messageHashes = append(messageHashes, message.getMessageHash());
        messageIds = append(messageIds, message.getMessageId());
    }

    private Message[] append(Message[] source, Message value) {
        Message[] result = Arrays.copyOf(source, source.length + 1);
        result[source.length] = value;
        return result;
    }

    private String[] append(String[] source, String value) {
        String[] result = Arrays.copyOf(source, source.length + 1);
        result[source.length] = value;
        return result;
    }

    public String[] getSentMessageTexts() {
        return Arrays.stream(sentMessages).map(Message::getMessage).toArray(String[]::new);
    }

    public Message[] getSentMessages() { return Arrays.copyOf(sentMessages, sentMessages.length); }
    public Message[] getDisregardedMessages() { return Arrays.copyOf(disregardedMessages, disregardedMessages.length); }
    public Message[] getStoredMessages() { return Arrays.copyOf(storedMessages, storedMessages.length); }
    public String[] getMessageHashes() { return Arrays.copyOf(messageHashes, messageHashes.length); }
    public String[] getMessageIds() { return Arrays.copyOf(messageIds, messageIds.length); }

    public int returnTotalMessagesSent() { return sentMessages.length; }

    public String displayStoredSendersAndRecipients() {
        if (storedMessages.length == 0) return "No stored messages found.";
        return Arrays.stream(storedMessages)
                .map(m -> "Sender: " + safe(m.getSender()) + " | Recipient: " + m.getRecipient())
                .collect(Collectors.joining(System.lineSeparator()));
    }

    public Optional<Message> findLongestStoredMessage() {
        return Arrays.stream(storedMessages)
                .max((a, b) -> Integer.compare(
                        a.getMessage() == null ? 0 : a.getMessage().length(),
                        b.getMessage() == null ? 0 : b.getMessage().length()));
    }

    public Optional<Message> searchByMessageId(String id) {
        return allMessages().stream()
                .filter(m -> m.getMessageId() != null && m.getMessageId().equals(id))
                .findFirst();
    }

    public List<Message> searchByRecipient(String recipient) {
        return allMessages().stream()
                .filter(m -> recipient != null && recipient.equals(m.getRecipient()))
                .filter(m -> m.getStatus() == Message.Status.SENT || m.getStatus() == Message.Status.STORED)
                .collect(Collectors.toList());
    }

    public String deleteByHash(String hash) {
        Message target = Arrays.stream(storedMessages)
                .filter(m -> m.getMessageHash().equalsIgnoreCase(hash))
                .findFirst().orElse(null);
        if (target == null) return "No stored message found with that message hash.";

        storedMessages = Arrays.stream(storedMessages)
                .filter(m -> !m.getMessageHash().equalsIgnoreCase(hash))
                .toArray(Message[]::new);
        rebuildIdAndHashArrays();
        saveStoredMessages();
        return "Message: \"" + target.getMessage() + "\" successfully deleted.";
    }

    public String displayStoredReport() {
        if (storedMessages.length == 0) return "No stored messages found.";
        StringBuilder report = new StringBuilder("STORED MESSAGE REPORT")
                .append(System.lineSeparator()).append("====================").append(System.lineSeparator());
        for (Message m : storedMessages) {
            report.append("Message ID: ").append(m.getMessageId()).append(System.lineSeparator())
                    .append("Message Hash: ").append(m.getMessageHash()).append(System.lineSeparator())
                    .append("Sender: ").append(safe(m.getSender())).append(System.lineSeparator())
                    .append("Recipient: ").append(m.getRecipient()).append(System.lineSeparator())
                    .append("Message: ").append(m.getMessage()).append(System.lineSeparator())
                    .append("--------------------").append(System.lineSeparator());
        }
        return report.toString();
    }

    public List<Message> allMessages() {
        List<Message> all = new ArrayList<>();
        all.addAll(Arrays.asList(sentMessages));
        all.addAll(Arrays.asList(storedMessages));
        all.addAll(Arrays.asList(disregardedMessages));
        return all;
    }

    private String safe(String value) { return value == null ? "Unknown" : value; }

    private void rebuildIdAndHashArrays() {
        List<Message> all = allMessages();
        messageIds = all.stream().map(Message::getMessageId).toArray(String[]::new);
        messageHashes = all.stream().map(Message::getMessageHash).toArray(String[]::new);
    }

    public void saveStoredMessages() {
        try {
            Path parent = jsonFile.getParent();
            if (parent != null) Files.createDirectories(parent);
            mapper.writeValue(jsonFile.toFile(), storedMessages);
        } catch (IOException e) {
            throw new IllegalStateException("Could not save stored messages to JSON: " + e.getMessage(), e);
        }
    }

    private void loadStoredMessages() {
        if (!Files.exists(jsonFile)) return;
        try {
            Message[] loaded = mapper.readValue(jsonFile.toFile(), new TypeReference<Message[]>() {});
            storedMessages = loaded == null ? new Message[0] : loaded;
            rebuildIdAndHashArrays();
        } catch (IOException e) {
            throw new IllegalStateException("Could not read stored messages JSON: " + e.getMessage(), e);
        }
    }
}
