package za.co.quickchat;

import java.security.SecureRandom;
import java.util.Locale;

public class Message {
    public enum Status { SENT, STORED, DISREGARDED }

    private static final SecureRandom RANDOM = new SecureRandom();

    private String messageId;
    private int messageNumber;
    private String sender;
    private String recipient;
    private String message;
    private String messageHash;
    private Status status;


    public Message() { }

    public Message(int messageNumber, String sender, String recipient,
                   String message, Status status) {
        this(String.format("%010d", RANDOM.nextInt(1_000_000_000)),
                messageNumber, sender, recipient, message, status);
    }

    public Message(String messageId, int messageNumber, String sender,
                   String recipient, String message, Status status) {
        this.messageId = messageId;
        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient;
        this.message = message;
        this.status = status;
        this.messageHash = createMessageHash();
    }

    public boolean checkMessageID() {
        return messageId != null && messageId.matches("\\d{1,10}");
    }

    /**
     * Uses the same South African international number format as Part 1.
     * Returns the required success/failure message.
     */
    public String checkRecipientCell() {
        return recipient != null && recipient.matches("^\\+27[0-9]{9}$")
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String validateMessageLength() {
        if (message == null) return "Message ready to send.";
        if (message.length() <= 250) return "Message ready to send.";
        return "Message exceeds 250 characters by " + (message.length() - 250)
                + "; please reduce the size.";
    }

    public String createMessageHash() {
        if (messageId == null || message == null) return "";
        String[] words = message.trim().split("\\s+");
        String first = words.length == 0 ? "" : cleanWord(words[0]);
        String last = words.length == 0 ? "" : cleanWord(words[words.length - 1]);
        String idPrefix = messageId.length() >= 2
                ? messageId.substring(0, 2) : String.format("%2s", messageId).replace(' ', '0');
        return (idPrefix + ":" + messageNumber + ":" + first + last)
                .toUpperCase(Locale.ROOT);
    }

    private String cleanWord(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "");
    }

    /** Returns the result of the user's send/store/disregard selection. */
    public String SentMessage(String choice) {
        if (choice == null) return "Invalid message option.";
        return switch (choice.trim().toLowerCase(Locale.ROOT)) {
            case "1", "send", "send message" -> {
                status = Status.SENT;
                yield "Message successfully sent.";
            }
            case "2", "discard", "disregard", "disregard message", "0" -> {
                status = Status.DISREGARDED;
                yield "Press 0 to delete the message.";
            }
            case "3", "store", "store message" -> {
                status = Status.STORED;
                yield "Message successfully stored.";
            }
            default -> "Invalid message option.";
        };
    }

    public String printMessages() {
        return "Message ID: " + messageId
                + System.lineSeparator() + "Message Hash: " + messageHash
                + System.lineSeparator() + "Recipient: " + recipient
                + System.lineSeparator() + "Message: " + message
                + System.lineSeparator() + "Status: " + status;
    }

    public static int returnTotalMessagess(Iterable<Message> messages) {
        int count = 0;
        for (Message ignored : messages) count++;
        return count;
    }

    public int returnTotalMessagess() { return 1; }

    public String getMessageId() { return messageId; }
    public int getMessageNumber() { return messageNumber; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }
    public Status getStatus() { return status; }

    public void setMessageId(String messageId) { this.messageId = messageId; }
    public void setMessageNumber(int messageNumber) { this.messageNumber = messageNumber; }
    public void setSender(String sender) { this.sender = sender; }
    public void setRecipient(String recipient) { this.recipient = recipient; }
    public void setMessage(String message) { this.message = message; }
    public void setMessageHash(String messageHash) { this.messageHash = messageHash; }
    public void setStatus(Status status) { this.status = status; }
}
