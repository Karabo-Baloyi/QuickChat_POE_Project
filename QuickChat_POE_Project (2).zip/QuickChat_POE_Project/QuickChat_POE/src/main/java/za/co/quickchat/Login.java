package za.co.quickchat;

import java.util.regex.Pattern;


public class Login {
    private final String username;
    private final String password;
    private final String cellPhoneNumber;
    private User registeredUser;

    public Login(String username, String password, String cellPhoneNumber) {
        this.username = username == null ? "" : username;
        this.password = password == null ? "" : password;
        this.cellPhoneNumber = cellPhoneNumber == null ? "" : cellPhoneNumber;
    }

    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        return password.length() >= 8
                && Pattern.compile("[A-Z]").matcher(password).find()
                && Pattern.compile("[0-9]").matcher(password).find()
                && Pattern.compile("[^A-Za-z0-9]").matcher(password).find();
    }

    public boolean checkCellPhoneNumber() {
        return Pattern.matches("^\\+27[0-9]{9}$", cellPhoneNumber);
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }
        return "User registered successfully.";
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return registeredUser != null
                && registeredUser.getUsername().equals(enteredUsername)
                && registeredUser.getPassword().equals(enteredPassword);
    }

    public String returnLoginStatus(boolean loginStatus, String firstName, String lastName) {
        if (loginStatus) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    public void setRegisteredUser(User user) { this.registeredUser = user; }
    public User getRegisteredUser() { return registeredUser; }
}
