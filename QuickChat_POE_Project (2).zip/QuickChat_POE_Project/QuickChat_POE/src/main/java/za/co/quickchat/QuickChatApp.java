package za.co.quickchat;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;


public class QuickChatApp {
    private final Scanner scanner = new Scanner(System.in);
    private final MessageManager manager = new MessageManager();
    private User currentUser;
    private int messageCounter = 0;

    public static void main(String[] args) {
        new QuickChatApp().start();
    }

    public void start() {
        System.out.println("=================================");
        System.out.println("       QUICKCHAT APPLICATION");
        System.out.println("=================================");
        if (!registerAndLogin()) {
            System.out.println("Application closed.");
            return;
        }

        System.out.println("\\nWelcome to QuickChat.");
        boolean running = true;
        while (running) {
            showMainMenu();
            int choice = readInt("Select an option: ");
            switch (choice) {
                case 1 -> sendMessages();
                case 2 -> System.out.println("Coming Soon.");
                case 3 -> {
                    System.out.println("Thank you for using QuickChat.");
                    running = false;
                }
                case 4 -> storedMessagesMenu();
                default -> System.out.println("Please select a valid menu option.");
            }
        }
    }

    private boolean registerAndLogin() {
        System.out.println("\\n--- User Registration ---");
        System.out.print("First name: ");
        String first = scanner.nextLine().trim();
        System.out.print("Last name: ");
        String last = scanner.nextLine().trim();
        System.out.print("Username (underscore, max 5 characters): ");
        String username = scanner.nextLine().trim();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        System.out.print("South African cellphone (+27XXXXXXXXX): ");
        String cell = scanner.nextLine().trim();

        Login login = new Login(username, password, cell);
        if (!login.checkUserName()) {
            System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            return false;
        }
        System.out.println("Username successfully captured.");
        if (!login.checkPasswordComplexity()) {
            System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            return false;
        }
        System.out.println("Password successfully captured.");
        if (!login.checkCellPhoneNumber()) {
            System.out.println("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.");
            return false;
        }
        System.out.println("Cell phone number successfully added.");

        currentUser = new User(first, last, username, password, cell);
        login.setRegisteredUser(currentUser);

        System.out.println("\\n--- Login ---");
        System.out.print("Username: ");
        String enteredUsername = scanner.nextLine().trim();
        System.out.print("Password: ");
        String enteredPassword = scanner.nextLine();
        boolean success = login.loginUser(enteredUsername, enteredPassword);
        System.out.println(login.returnLoginStatus(success, first, last));
        return success;
    }

    private void showMainMenu() {
        System.out.println("\\n--------- QUICKCHAT MENU ---------");
        System.out.println("1) Send Messages");
        System.out.println("2) Show recently sent messages");
        System.out.println("3) Quit");
        System.out.println("4) Stored Messages");
    }

    private void sendMessages() {
        int amount = readInt("How many messages would you like to enter? ");
        if (amount <= 0) {
            System.out.println("Enter a number greater than zero.");
            return;
        }

        for (int i = 0; i < amount; i++) {
            messageCounter++;
            System.out.println("\\n--- Message " + messageCounter + " of " + amount + " ---");
            System.out.print("Recipient cellphone (+27XXXXXXXXX): ");
            String recipient = scanner.nextLine().trim();
            System.out.print("Message (maximum 250 characters): ");
            String text = scanner.nextLine();

            Message message = new Message(messageCounter, currentUser.getCellPhoneNumber(),
                    recipient, text, Message.Status.STORED);

            if (!message.checkMessageID()) {
                System.out.println("Message ID could not be generated. Please try again.");
                messageCounter--;
                continue;
            }
            System.out.println("Message ID generated: " + message.getMessageId());
            if (!"Cell phone number successfully captured.".equals(message.checkRecipientCell())) {
                System.out.println(message.checkRecipientCell());
                messageCounter--;
                continue;
            }
            String lengthStatus = message.validateMessageLength();
            if (!"Message ready to send.".equals(lengthStatus)) {
                System.out.println(lengthStatus);
                messageCounter--;
                continue;
            }

            System.out.println("Message Hash: " + message.getMessageHash());
            System.out.println("Choose: 1) Send Message  2) Disregard Message  3) Store Message");
            String choice = scanner.nextLine().trim();
            String result = message.SentMessage(choice);
            System.out.println(result);
            if (choice.equals("2") || choice.equalsIgnoreCase("discard")
                    || choice.equalsIgnoreCase("disregard")) {
                System.out.print("Enter 0 to confirm deletion, or anything else to keep it disregarded: ");
                String delete = scanner.nextLine().trim();
                if (!delete.equals("0")) manager.add(message);
            } else if (message.getStatus() == Message.Status.SENT
                    || message.getStatus() == Message.Status.STORED) {
                manager.add(message);
                System.out.println("\\n" + message.printMessages());
            }
        }
        System.out.println("\\nTotal messages sent: " + manager.returnTotalMessagesSent());
    }

    private void storedMessagesMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\\n------ STORED MESSAGES ------");
            System.out.println("1) Display sender and recipient of stored messages");
            System.out.println("2) Display longest stored message");
            System.out.println("3) Search for a message ID");
            System.out.println("4) Search messages for a recipient");
            System.out.println("5) Delete a stored message using its hash");
            System.out.println("6) Display full stored-message report");
            System.out.println("7) Back to main menu");
            int choice = readInt("Select an option: ");
            switch (choice) {
                case 1 -> System.out.println(manager.displayStoredSendersAndRecipients());
                case 2 -> {
                    Optional<Message> longest = manager.findLongestStoredMessage();
                    System.out.println(longest.map(m -> "Longest stored message: " + m.getMessage())
                            .orElse("No stored messages found."));
                }
                case 3 -> {
                    System.out.print("Enter message ID: ");
                    String id = scanner.nextLine().trim();
                    Optional<Message> found = manager.searchByMessageId(id);
                    System.out.println(found.map(m -> "Recipient: " + m.getRecipient()
                            + "\\nMessage: " + m.getMessage()).orElse("Message ID not found."));
                }
                case 4 -> {
                    System.out.print("Enter recipient cellphone: ");
                    String recipient = scanner.nextLine().trim();
                    List<Message> matches = manager.searchByRecipient(recipient);
                    if (matches.isEmpty()) System.out.println("No sent or stored messages found for this recipient.");
                    else matches.forEach(m -> System.out.println(m.getMessage()));
                }
                case 5 -> {
                    System.out.print("Enter message hash: ");
                    System.out.println(manager.deleteByHash(scanner.nextLine().trim()));
                }
                case 6 -> System.out.println(manager.displayStoredReport());
                case 7 -> back = true;
                default -> System.out.println("Please select a valid option.");
            }
        }
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
