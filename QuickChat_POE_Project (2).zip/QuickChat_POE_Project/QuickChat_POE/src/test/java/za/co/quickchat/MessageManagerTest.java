package za.co.quickchat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class MessageManagerTest {
    @TempDir Path tempDir;

    private Message message(String id, int number, String recipient, String text, Message.Status status) {
        return new Message(id, number, "0838884567", recipient, text, status);
    }

    @Test void arraysArePopulatedByMessageStatus() {
        MessageManager manager = new MessageManager(tempDir.resolve("stored.json"));
        manager.add(message("0000000001", 1, "+27834557896", "Did you get the cake?", Message.Status.SENT));
        manager.add(message("0000000002", 2, "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", Message.Status.STORED));
        manager.add(message("0000000003", 3, "+27834484567", "Yohoooo, I am at your gate.", Message.Status.DISREGARDED));
        manager.add(message("0000000004", 4, "+27838884567", "It is dinner time !", Message.Status.SENT));
        manager.add(message("0000000005", 5, "+27838884567", "Ok, I am leaving without you.", Message.Status.STORED));

        assertArrayEquals(new String[]{"Did you get the cake?", "It is dinner time !"},
                manager.getSentMessageTexts());
        assertEquals(2, manager.getSentMessages().length);
        assertEquals(1, manager.getDisregardedMessages().length);
        assertEquals(2, manager.getStoredMessages().length);
        assertEquals(5, manager.getMessageIds().length);
        assertEquals(5, manager.getMessageHashes().length);
    }

    @Test void findsLongestStoredMessage() {
        MessageManager manager = new MessageManager(tempDir.resolve("stored.json"));
        manager.add(message("0000000002", 2, "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", Message.Status.STORED));
        manager.add(message("0000000005", 5, "+27838884567",
                "Ok, I am leaving without you.", Message.Status.STORED));
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                manager.findLongestStoredMessage().orElseThrow().getMessage());
    }

    @Test void searchesByIdAndRecipient() {
        MessageManager manager = new MessageManager(tempDir.resolve("stored.json"));
        manager.add(message("0000000004", 4, "+27838884567", "It is dinner time !", Message.Status.SENT));
        manager.add(message("0000000002", 2, "+27838884567", "Where are you?", Message.Status.STORED));
        manager.add(message("0000000005", 5, "+27838884567", "Ok, I am leaving without you.", Message.Status.STORED));

        assertEquals("It is dinner time !", manager.searchByMessageId("0000000004").orElseThrow().getMessage());
        List<Message> matches = manager.searchByRecipient("+27838884567");
        assertEquals(3, matches.size());
    }

    @Test void deletesStoredMessageUsingHashAndUpdatesJson() {
        Path json = tempDir.resolve("stored.json");
        MessageManager manager = new MessageManager(json);
        Message stored = message("0000000002", 2, "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", Message.Status.STORED);
        manager.add(stored);

        assertTrue(manager.deleteByHash(stored.getMessageHash()).contains("successfully deleted"));
        assertEquals(0, manager.getStoredMessages().length);

        MessageManager reloaded = new MessageManager(json);
        assertEquals(0, reloaded.getStoredMessages().length);
    }

    @Test void jsonPersistsStoredMessagesAndReportContainsRequiredFields() {
        Path json = tempDir.resolve("stored.json");
        MessageManager manager = new MessageManager(json);
        manager.add(message("0000000002", 2, "+27838884567", "A stored message", Message.Status.STORED));

        MessageManager reloaded = new MessageManager(json);
        assertEquals(1, reloaded.getStoredMessages().length);
        String report = reloaded.displayStoredReport();
        assertTrue(report.contains("Message Hash:"));
        assertTrue(report.contains("Recipient:"));
        assertTrue(report.contains("Message: A stored message"));
    }
}
