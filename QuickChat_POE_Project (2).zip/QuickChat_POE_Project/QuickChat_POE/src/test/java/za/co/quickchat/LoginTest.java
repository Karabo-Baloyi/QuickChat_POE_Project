package za.co.quickchat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LoginTest {
    @Test void usernameCorrectlyFormatted() {
        assertTrue(new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976").checkUserName());
    }

    @Test void usernameIncorrectlyFormatted() {
        assertFalse(new Login("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976").checkUserName());
    }

    @Test void passwordMeetsComplexity() {
        assertTrue(new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976").checkPasswordComplexity());
        assertEquals("Password successfully captured.",
                new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976").checkPasswordComplexity()
                        ? "Password successfully captured." : "failed");
    }

    @Test void passwordFailsComplexity() {
        assertFalse(new Login("kyl_1", "password", "+27838968976").checkPasswordComplexity());
    }

    @Test void cellphoneCorrectlyFormatted() {
        assertTrue(new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976").checkCellPhoneNumber());
    }

    @Test void cellphoneIncorrectlyFormatted() {
        assertFalse(new Login("kyl_1", "Ch&&sec@ke99!", "08966553").checkCellPhoneNumber());
    }

    @Test void loginSuccessAndFailure() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        login.setRegisteredUser(new User("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976"));
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
        assertFalse(login.loginUser("kyl_1", "wrong"));
    }
}
