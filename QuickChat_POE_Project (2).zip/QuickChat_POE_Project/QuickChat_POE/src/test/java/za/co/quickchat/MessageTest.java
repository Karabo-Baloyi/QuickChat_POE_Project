package za.co.quickchat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MessageTest {
    @Test void messageIdAndRecipientValidation() {
        Message good = new Message("0012345678", 0, "sender", "+27718693002",
                "Hi Mike, can you join us for dinner tonight?", Message.Status.SENT);
        assertTrue(good.checkMessageID());
        assertEquals("Cell phone number successfully captured.", good.checkRecipientCell());

        Message bad = new Message("12345678901", 1, "sender", "08575975889",
                "Hello", Message.Status.SENT);
        assertFalse(bad.checkMessageID());
        assertTrue(bad.checkRecipientCell().startsWith("Cell phone number is incorrectly formatted"));
    }

    @Test void messageLengthSuccessAndFailure() {
        Message good = new Message("0012345678", 1, "sender", "+27718693002",
                "Short message", Message.Status.SENT);
        assertEquals("Message ready to send.", good.validateMessageLength());

        Message longMessage = new Message("0012345679", 2, "sender", "+27718693002",
                "x".repeat(251), Message.Status.SENT);
        assertEquals("Message exceeds 250 characters by 1; please reduce the size.",
                longMessage.validateMessageLength());
    }

    @Test void messageHashUsesFirstTwoIdDigitsAndFirstAndLastWords() {
        Message message = new Message("0012345678", 0, "sender", "+27718693002",
                "Hi Mike, can you join us for dinner tonight?", Message.Status.SENT);
        assertEquals("00:0:HITONIGHT", message.getMessageHash());
    }

    @Test void sendStoreAndDisregardChoices() {
        Message sent = new Message("0012345678", 1, "sender", "+27718693002", "Hello", Message.Status.STORED);
        assertEquals("Message successfully sent.", sent.SentMessage("1"));
        assertEquals(Message.Status.SENT, sent.getStatus());

        Message discarded = new Message("0012345679", 2, "sender", "+27718693002", "Hello", Message.Status.SENT);
        assertEquals("Press 0 to delete the message.", discarded.SentMessage("2"));
        assertEquals(Message.Status.DISREGARDED, discarded.getStatus());

        Message stored = new Message("0012345680", 3, "sender", "+27718693002", "Hello", Message.Status.SENT);
        assertEquals("Message successfully stored.", stored.SentMessage("3"));
        assertEquals(Message.Status.STORED, stored.getStatus());
    }
}
